import test from 'node:test';
import assert from 'node:assert/strict';
import {makeStickerGlb,registerModel,getModel,arProduct} from '../lib/ar.mjs';
import {removeEdgeWhite} from '../public/ar-texture.js';
import {createServer} from '../server.mjs';
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==','base64');
test('GLB carries physical metre dimensions, embedded cutout PNG and correctly aligned buffers',()=>{
 const model=makeStickerGlb(png,76.2,30),b=model.bytes;assert.equal(b.readUInt32LE(0),0x46546c67);assert.equal(b.readUInt32LE(8),b.length);
 const n=b.readUInt32LE(12),g=JSON.parse(b.toString('utf8',20,20+n));assert.deepEqual(g.accessors[0].max,[.0381,0,.015]);assert.equal(g.materials[0].alphaMode,'MASK');assert.equal(g.images[0].mimeType,'image/png');assert.ok(g.bufferViews.every(v=>v.byteOffset%4===0));assert.equal(g.buffers[0].byteLength,b.readUInt32LE(20+n));assert.equal(g.images[0].uri,undefined);const uvOffset=28+n+g.bufferViews[2].byteOffset;assert.equal(b.readFloatLE(uvOffset+4),1);assert.equal(b.readFloatLE(uvOffset+20),0);
});
test('unverified catalog dimensions remain unknown and unsupported apparel is excluded',()=>{assert.equal(arProduct('wasted-sticker').widthMm,null);assert.equal(arProduct('secret-invasion-t-shirt'),null);assert.equal(arProduct('not-real'),null);});
test('model generation rejects unsafe dimensions, malformed PNG and excessive texture sizes',()=>{
 for(const width of [0,-4,NaN,Infinity,1001])assert.throws(()=>makeStickerGlb(png,width));assert.throws(()=>makeStickerGlb(Buffer.from('wrong'),30));const huge=Buffer.from(png);huge.writeUInt32BE(99999,16);assert.throws(()=>makeStickerGlb(huge,30));assert.throws(()=>registerModel({png:'https://example.com/image.png',widthMm:50}));
});
test('texture removal keeps enclosed white artwork and original colour pixels',()=>{
 const data=new Uint8ClampedArray(5*5*4).fill(255);for(const n of [6,7,8,11,13,16,17,18]){data[n*4]=0;data[n*4+1]=0;data[n*4+2]=0;}removeEdgeWhite(data,5,5);assert.equal(data[3],0);assert.equal(data[12*4+3],255);assert.equal(data[6*4+3],255);
});
test('registered models are content-addressed and returned as binary GLB',()=>{const input={png:`data:image/png;base64,${png.toString('base64')}`,widthMm:50};const one=registerModel(input),two=registerModel(input);assert.equal(one.url,two.url);assert.ok(getModel(one.url.split('/').pop().slice(0,-4)));assert.equal(getModel('unknown'),null);});
test('AR routes expose preview, reject bad models, and serve generated assets with correct MIME',async()=>{
 const server=createServer();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
 try{for(const route of ['/pages/try-live?product=wasted-sticker','/pages/try-live?layout=cart','/ar.js','/ar-texture.js','/ar.css','/vendor/model-viewer/model-viewer.js'])assert.equal((await fetch(origin+route)).status,200,route);
 const arPolicy=(await fetch(origin+'/pages/try-live')).headers.get('content-security-policy');assert.ok(arPolicy.includes("'wasm-unsafe-eval'"));assert.ok(!arPolicy.includes("'unsafe-eval'"));assert.ok(!(await fetch(origin+'/')).headers.get('content-security-policy').includes('wasm-unsafe-eval'));
 assert.equal((await fetch(origin+'/pages/try-live?product=secret-invasion-t-shirt')).status,404);
 const response=await fetch(origin+'/api/ar/prepare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({png:`data:image/png;base64,${png.toString('base64')}`,widthMm:50})});assert.equal(response.status,200);const result=await response.json(),model=await fetch(origin+result.url);assert.equal(model.headers.get('content-type'),'model/gltf-binary');assert.equal((await model.arrayBuffer()).byteLength,makeStickerGlb(png,50).bytes.length);
 assert.equal((await fetch(origin+'/api/ar/prepare',{method:'POST',body:'{"png":"bad"}'})).status,422);
 }finally{await new Promise(resolve=>server.close(resolve));}
});
