import {createHandoff,getHandoff,handoffQr,phonePreviewOrigin,validPhoneOrigin} from './lib/ar-handoff.mjs';
import {arProduct,registerModel,getModel} from './lib/ar.mjs';
import http from 'node:http';
import {discover} from './lib/taste.mjs';
import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {products,byHandle,collections,selectProducts,quote} from './lib/catalog.mjs';
import {homePage,collectionPage,productPage,capturedPage,collectionIndex,localPage,notFound,hasCaptured,card,image,studioPage,discoveryPage,arPage} from './lib/render.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const mime={'.css':'text/css','.js':'text/javascript','.json':'application/json','.txt':'text/plain; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.jpg':'image/jpeg','.png':'image/png','.woff2':'font/woff2','.woff':'font/woff'};
const security={
 'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
 'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https:; img-src 'self' https: data:; font-src 'self' https: data:; connect-src 'self'; form-action 'self'; frame-src 'none'; base-uri 'self'; object-src 'none'"
};
// model-viewer decodes textures from blob URLs and initializes a bundled WASM helper.
// Permit these only on the AR page; JavaScript string evaluation remains blocked.
const arSecurity={...security,'Content-Security-Policy':security['Content-Security-Policy'].replace("script-src 'self'", "script-src 'self' 'wasm-unsafe-eval'").replace("img-src 'self' https: data:","img-src 'self' https: data: blob:").replace("connect-src 'self'", "connect-src 'self' blob: data:")};
async function body(req,limit=64000){let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>limit)throw new Error('Request is too large.');}return JSON.parse(raw||'{}');}
export function createServer(options={}){return http.createServer(async(req,res)=>{
 const send=(status,data,type='text/html; charset=utf-8')=>{res.writeHead(status,{...(req.url.split('?')[0]==='/pages/try-live'?arSecurity:security),'Content-Type':type});res.end(data);};
 const json=(status,data)=>send(status,JSON.stringify(data),'application/json; charset=utf-8');
 try{
   const url=new URL(req.url,'http://localhost');
   const route=decodeURIComponent(url.pathname);
   if(req.method==='GET'&&route==='/api/ar/handoff-config'){
     const origin=options.phoneOrigin===undefined?await phonePreviewOrigin():validPhoneOrigin(options.phoneOrigin);return json(200,{enabled:Boolean(origin),origin});
   }
   if(req.method==='POST'&&route==='/api/ar/handoffs'){
     const origin=options.phoneOrigin===undefined?await phonePreviewOrigin():validPhoneOrigin(options.phoneOrigin);
     if(!origin)return json(409,{error:'Phone preview is not configured. Start the HTTPS phone preview, then retry.'});
     try{return json(200,createHandoff(await body(req),origin));}catch(error){return json(422,{error:error.message});}
   }
   if(req.method==='GET'&&/^\/api\/ar\/handoffs\/[a-f0-9]{32}(\/qr\.png)?$/.test(route)){
     const token=route.split('/')[4];res.setHeader('Cache-Control','no-store');
     if(route.endsWith('/qr.png')){const png=await handoffQr(token);return png?send(200,png,'image/png'):json(410,{error:'This QR expired. Create a new one on your laptop.'});}
     const scene=getHandoff(token);return json(scene?200:410,scene||{error:'This preview expired. Create a new QR on your laptop.'});
   }
   if(req.method==='POST'&&route==='/api/ar/prepare'){
     try{return json(200,registerModel(await body(req,4_100_000)));}catch(error){return json(422,{error:error.message});}
   }
   if(req.method==='GET'&&route.startsWith('/api/ar/products/')){const p=arProduct(route.split('/').pop());return json(p?200:404,p||{error:'This product is not supported for sticker AR.'});}
   if(req.method==='GET'&&/^\/api\/ar\/models\/[a-f0-9]{64}\.glb$/.test(route)){const model=getModel(route.split('/').pop().slice(0,-4));return model?send(200,model,'model/gltf-binary'):json(410,{error:'Preview expired. Prepare it again.'});}
   if(req.method==='GET'&&route.startsWith('/api/ar/image/')){
     const p=byHandle.get(route.split('/').pop());if(!arProduct(p?.handle))return json(404,{error:'Sticker not found.'});
     const src=image(p,1000,true);
     if(src.startsWith('/assets/'))return send(200,await readFile(path.join(root,'public',src)), 'image/png');
     // Source comes only from the captured product catalog, never a caller-supplied URL.
     try{const remote=await fetch(src,{signal:AbortSignal.timeout(15000),redirect:'error'});const type=remote.headers.get('content-type')||'';if(!remote.ok||!/^image\/(png|jpeg|webp|gif)(;|$)/i.test(type))throw new Error('Image unavailable');const reader=remote.body.getReader();let size=0;const parts=[];try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>8_000_000)throw new Error('Image is too large');parts.push(Buffer.from(value));}}finally{await reader.cancel();}return send(200,Buffer.concat(parts),type);}catch{return json(502,{error:'The catalog image could not load. Try again.'});}
   }
   if(req.method==='POST'&&route==='/api/discover'){
     const result=discover((await body(req)).history);
     return json(200,{...result,deck:result.deck.map(p=>({id:p.id,title:p.title,handle:p.handle,image:image(p,600,true),price:Number(p.variants.find(v=>v.available).price)})),feed:undefined,feedHtml:result.feed.map(card).join('')});
   }
   if(req.method==='POST'&&route==='/api/cart/quote'){
     try{return json(200,quote((await body(req)).items));}catch(error){return json(422,{error:error.message});}
   }
   if(req.method!=='GET'&&req.method!=='HEAD')return json(405,{error:'Method not allowed'});
   if(route==='/api/health')return json(200,{ok:true,products:products.length,collections:collections().length});
   if(route==='/api/products')return json(200,selectProducts(url.searchParams,url.searchParams.get('collection')||'all'));
   if(route.startsWith('/api/products/')){const p=byHandle.get(route.split('/').pop());return json(p?200:404,p||{error:'Product not found'});}
   if(route==='/api/collections')return json(200,collections().map(({title,handle,product_count})=>({title,handle,product_count})));
   if(route==='/robots.txt')return send(200,'User-agent: *\nDisallow: /\n','text/plain');
   if(route==='/favicon.ico'){res.writeHead(204);return res.end();}
   const ext=path.extname(route);
   if(ext&&mime[ext]){
     const file=path.resolve(root,'public','.'+route),publicRoot=path.join(root,'public')+path.sep;
     if(!file.startsWith(publicRoot))return send(403,'Forbidden');
     try{await stat(file);return send(200,await readFile(file),mime[ext]);}catch{return send(404,'File not found','text/plain');}
   }
   if(route==='/')return send(200,homePage());
   if(route==='/pages/try-live'){const html=arPage(url);return send(html?200:404,html||notFound());}
   if(route==='/pages/sticker-studio')return send(200,studioPage());
   if(route==='/pages/find-your-vibe')return send(200,discoveryPage());
   if(route==='/collections')return send(200,collectionIndex());
   if(route.startsWith('/products/')||/\/products\//.test(route)){
     const handle=route.split('/products/').pop();const p=byHandle.get(handle);
     return send(p?200:404,p?productPage(p,url):notFound());
   }
   if(route.startsWith('/collections/')||route==='/search'){const result=collectionPage(url);return send(result.status,result.html);}
   if(['/cart','/checkout','/pages/track-your-order'].includes(route)||route.startsWith('/account'))return send(200,localPage(route));
   if(hasCaptured(route))return send(200,capturedPage(route));
   return send(404,notFound());
 }catch(error){console.error(error);return json(500,{error:'Unable to load this page.'});}
});}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const port=Number(process.env.PORT)||3000;
 createServer().listen(port,'0.0.0.0',()=>console.log(`STICK IT UP recreation: http://localhost:${port}`));
}
