import {stickerTexture} from './ar-texture.js';
const root=document.querySelector('#ar-app');
if(root){
 const q=s=>root.querySelector(s),viewer=q('#sticker-ar'),status=q('#ar-status'),prepare=q('#ar-prepare'),launch=q('#ar-launch'),progress=q('#ar-progress'),width=q('#ar-width'),measured=q('#ar-measured'),cutout=q('#ar-cutout'),share=q('#ar-share'),qrStatus=q('#ar-qr-status');
 const layout=root.dataset.layout==='cart',shared=root.dataset.handoff;let handle=root.dataset.handle,revision=0,controller,enginePromise,readyUrl,expiryTimer,loadTimer;
 const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}};
 const say=(text,error=false)=>{status.textContent=text;status.classList.toggle('ar-error',error);};
 async function json(url,options={}){const res=await fetch(url,{signal:AbortSignal.timeout(20000),...options});const data=await res.json();if(!res.ok)throw new Error(data.error||'Unable to prepare preview.');return data;}
 function invalidate(){share.disabled=true;q('#ar-qr-result').hidden=true;q('#ar-qr-image').removeAttribute('src');qrStatus.textContent='Prepare the preview first. Your phone does not need the cart from this laptop.';revision++;controller?.abort();clearTimeout(loadTimer);clearTimeout(expiryTimer);readyUrl=null;launch.disabled=true;launch.hidden=true;viewer.hidden=true;viewer.removeAttribute('src');q('#ar-poster').hidden=false;progress.hidden=true;prepare.disabled=false;q('#ar-scale-tag').textContent=measured.checked?'Uses your entered width · verify physical fit':'Estimated size · not calibrated';q('#ar-current-size').textContent='';}
 function deviceInfo(){const secure=window.isSecureContext;q('#ar-device').textContent=!secure?'Live AR needs HTTPS on your phone. This HTTP address can only show the 3D preview.':viewer.canActivateAR?'This browser offers an AR viewer. Camera access starts only after you tap Try it live. On iPhone, Apple’s viewer opens; edit the layout here before opening it.':'You can inspect the 3D preview here. For tracked placement, open this same page in Safari on an iPhone or a compatible Android browser. AR availability is checked after the model loads.';launch.disabled=!secure||!viewer.canActivateAR;}
 for(const control of [width,measured,cutout])control.addEventListener('input',()=>{invalidate();say('Settings changed. Prepare the updated preview.');});
 function showMetadata(data){q('#ar-title').textContent=data.title;say('Ready to prepare. Set the width, then inspect the cutout and size before trying AR.');}
 async function setup(){
  if(shared){await loadShared();return;}
  try{if(layout){q('#ar-cutout-label').hidden=true;q('#ar-poster').alt='Your saved sticker arrangement';say('Save your arrangement in Laptop studio, then prepare it here.');}
  else{const data=await json(`/api/ar/products/${encodeURIComponent(handle)}`);showMetadata(data);
   const cart=read('stickitup-cart-v1',[]);if(Array.isArray(cart)&&cart.length){try{const quote=await json('/api/cart/quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:cart})});const list=[{handle,title:data.title},...quote.items.filter(i=>/^(Stickers|Bumper Sticker|Holographic stickers|Glitter Stickers|Infinity Stickers)$/.test(i.product_type))];const seen=new Set();for(const item of list){if(seen.has(item.handle))continue;seen.add(item.handle);const option=document.createElement('option');option.value=item.handle;option.textContent=item.title;q('#ar-picker').append(option);}q('#ar-picker-label').hidden=seen.size<2;}catch{/* Selected product still works when the cart cannot be quoted. */}}
  }
  q('#ar-device').textContent=window.isSecureContext?'Prepare the preview to check whether live AR is available on this device.':'Live AR requires HTTPS on your phone. You can still inspect the 3D preview here.';
  }catch(error){say(error.message,true);prepare.disabled=false;}
 }
 async function loadShared(){
  q('#ar-phone').hidden=true;prepare.hidden=true;prepare.disabled=true;width.disabled=true;measured.disabled=true;cutout.disabled=true;q('#ar-cutout-label').hidden=true;q('#ar-poster').hidden=true;progress.hidden=false;say('Opening the preview shared from your laptop…');
  q('#ar-device').nextElementSibling.textContent='To change a shared arrangement, edit it on your laptop and create a new QR.';
  q('#ar-size-note').textContent='This is the size prepared on your laptop. Edit there and create a new QR to change it.';
  try{if(!/^[a-f0-9]{32}$/.test(shared))throw new Error('This phone preview link is invalid. Create a new QR on your laptop.');const data=await json(`/api/ar/handoffs/${encodeURIComponent(shared)}`);q('#ar-title').textContent=data.title;width.value=(data.widthMm/10).toFixed(2);measured.checked=data.measured;q('#ar-scale-tag').textContent=data.measured?'Uses the width entered on your laptop':'Estimated size · not calibrated';
   q('#ar-current-size').textContent=`Shared preview: ${(data.widthMm/10).toFixed(2)} × ${(data.heightMm/10).toFixed(2)} cm. ${data.kind==='layout'?'The saved arrangement moves as one group.':''}`;
   await Promise.race([import('/vendor/model-viewer/model-viewer.js'),new Promise((_,reject)=>{loadTimer=setTimeout(()=>reject(new Error('The 3D viewer took too long to load. Reload to retry.')),20000);})]);clearTimeout(loadTimer);
   readyUrl=data.url;viewer.setAttribute('loading','eager');viewer.setAttribute('src',data.url);viewer.hidden=false;
   loadTimer=setTimeout(()=>{progress.hidden=true;say('The shared model could not load. Reload, or create a new QR on your laptop.',true);},25000);
   expiryTimer=setTimeout(()=>{readyUrl=null;launch.disabled=true;say('This shared preview expired. Create a new QR on your laptop.',true);},Math.max(0,data.expiresAt-Date.now()));
  }catch(error){clearTimeout(loadTimer);progress.hidden=true;say(error.message,true);q('#ar-device').textContent='Return to your laptop and create a new QR if the link has expired.';}
 }
 share.addEventListener('click',async()=>{
  if(!readyUrl){qrStatus.textContent='Prepare your preview before creating the QR.';return;}
  const token=revision,model=readyUrl;share.disabled=true;qrStatus.textContent='Creating a phone link for this prepared scene…';
  try{const result=await json('/api/ar/handoffs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,title:q('#ar-title').textContent,kind:layout?'layout':'single',measured:measured.checked})});if(token!==revision||model!==readyUrl)return;
   q('#ar-qr-image').src=result.qr;q('#ar-phone-link').href=result.url;q('#ar-qr-result').hidden=false;q('#ar-qr-result').scrollIntoView({block:'center',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
   q('#ar-qr-expiry').textContent=`This QR expires in ${Math.max(1,Math.floor((result.expiresAt-Date.now())/60000))} minutes. Keep the laptop preview running.`;
   qrStatus.textContent='Scan with your phone camera, open the link, then tap Try it live. No cart transfer or QR scanner app is needed.';
  }catch(error){if(token===revision)qrStatus.textContent=error.message;}finally{if(token===revision)share.disabled=false;}
 });
 q('#ar-qr-image').addEventListener('error',()=>{qrStatus.textContent='The QR image could not load. Use the phone preview link or generate the QR again.';});
 q('#ar-copy-link').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(q('#ar-phone-link').href);qrStatus.textContent='Phone preview link copied.';}catch{qrStatus.textContent='Copy is unavailable. Open the phone preview link and copy its address.';}});
 q('#ar-picker').addEventListener('change',async event=>{invalidate();handle=event.target.value;const token=revision;try{const data=await json(`/api/ar/products/${encodeURIComponent(handle)}`);if(token!==revision)return;showMetadata(data);q('#ar-poster').src=`/api/ar/image/${encodeURIComponent(handle)}`;q('#ar-poster').alt=data.title;const url=new URL(location.href);url.searchParams.set('product',handle);url.searchParams.delete('variant');history.replaceState(null,'',url);}catch(error){say(error.message,true);}});
 async function arrangement(signal){
  const saved=read('stickitup-studio-v1',[]);if(!Array.isArray(saved)||!saved.length)throw new Error('No saved arrangement. Open Laptop studio, place your stickers and choose Save layout first.');
  const cart=read('stickitup-cart-v1',[]),quote=await json('/api/cart/quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:Array.isArray(cart)?cart:[]}),signal});
  const pieces=saved.slice(0,25).filter(p=>p&&quote.items.some(i=>String(i.id)===String(p.id)&&/^(Stickers|Bumper Sticker|Holographic stickers|Glitter Stickers|Infinity Stickers)$/.test(i.product_type))),textures=new Map();
  if(!pieces.length)throw new Error('The saved arrangement has no stickers currently in your cart. Save a new layout.');
  for(const piece of pieces){const item=quote.items.find(i=>String(i.id)===String(piece.id));if(!textures.has(piece.id))textures.set(piece.id,await stickerTexture(item.handle,true,signal,false));}
  const canvas=document.createElement('canvas');canvas.width=1400;canvas.height=900;const ctx=canvas.getContext('2d');const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0));
  for(const piece of pieces){const image=textures.get(piece.id),size=1400*clamp(piece.size,8,42)/100,height=size*image.height/image.width;ctx.save();ctx.translate(clamp(piece.x,0,100)*14,clamp(piece.y,0,100)*9);ctx.rotate(clamp(piece.rotation,-180,180)*Math.PI/180);ctx.drawImage(image,-size/2,-height/2,size,height);ctx.restore();}return canvas;
 }
 prepare.addEventListener('click',async()=>{
  invalidate();const token=revision,cm=Number(width.value);if(!Number.isFinite(cm)||cm<.5||cm>100){say('Enter a width between 0.5 and 100 cm.',true);return;}
  controller=new AbortController();const current=controller;const preparationTimer=setTimeout(()=>current.abort(),45000);prepare.disabled=true;progress.hidden=false;say('Preparing the original artwork and 3D surface…');
  try{enginePromise ||= import('/vendor/model-viewer/model-viewer.js').catch(error=>{enginePromise=null;throw error;});
   const texture=layout?await arrangement(current.signal):await stickerTexture(handle,cutout.checked,current.signal);if(token!==revision)return;
   const model=await json('/api/ar/prepare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({png:texture.toDataURL('image/png'),widthMm:cm*10}),signal:current.signal});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('The 3D viewer took too long to load. Try again.')),20000);enginePromise.then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});if(token!==revision)return;
   readyUrl=model.url;viewer.setAttribute('loading','eager');viewer.setAttribute('src',model.url);viewer.hidden=false;q('#ar-poster').hidden=true;
   q('#ar-current-size').textContent=`Preview: ${(model.widthMm/10).toFixed(2)} × ${(model.heightMm/10).toFixed(2)} cm. ${measured.checked?'Width entered by you; height follows the artwork proportions.':'Estimated dimensions — verify against the printed sticker.'}`;
   loadTimer=setTimeout(()=>{if(token===revision&&progress.hidden===false){current.abort();invalidate();say('The 3D model took too long to load. Prepare it again.',true);}},25000);
   expiryTimer=setTimeout(()=>{if(token===revision){invalidate();say('This preview expired. Prepare it again to continue.');}},model.expiresInSeconds*1000);
  }catch(error){if(token!==revision)return;progress.hidden=true;prepare.disabled=false;say(error.name==='AbortError'?'Preparation stopped. Try again.':`Could not prepare the preview: ${error.message}`,true);}finally{clearTimeout(preparationTimer);}
 });
 viewer.addEventListener('load',()=>{if(!readyUrl||viewer.getAttribute('src')!==readyUrl)return;clearTimeout(loadTimer);progress.hidden=true;prepare.disabled=false;share.disabled=false;launch.hidden=false;deviceInfo();q('#ar-view-hint').textContent='Drag to inspect · Pinch to zoom · Physical scale uses the width above';say(viewer.canActivateAR?'Preview ready. Tap Try it live, scan a flat surface, then tap to place.':'3D preview ready. Live AR is unavailable on this device; the preview is not camera tracking.');});
 viewer.addEventListener('error',()=>{if(!readyUrl)return;clearTimeout(loadTimer);progress.hidden=true;prepare.disabled=false;launch.disabled=true;say('The model could not be displayed. Check your connection and prepare it again.',true);});
 launch.addEventListener('click',()=>{if(!readyUrl||!viewer.canActivateAR){deviceInfo();return;}say('Opening your AR viewer. Move slowly to find a flat surface, then tap to place.');viewer.activateAR().catch(error=>say(`AR could not open: ${error.message}. You can still use the 3D preview.`,true));});
 viewer.addEventListener('ar-status',event=>{if(event.detail.status==='failed')say('AR could not start. Check device support and camera permission, then try again.',true);if(event.detail.status==='object-placed')say('Sticker placed. Move around slowly to inspect alignment and size.');if(event.detail.status==='not-presenting')deviceInfo();});
 viewer.addEventListener('ar-tracking',event=>{if(event.detail.status==='not-tracking')say('Tracking lost. Hold the phone steady and rescan a detailed, well-lit surface.');});
 window.addEventListener('pagehide',()=>{controller?.abort();clearTimeout(expiryTimer);clearTimeout(loadTimer);});setup();
}
