// Remove only white pixels connected to the outer edge, retaining enclosed white artwork.
export function removeEdgeWhite(data,width,height){
 const visited=new Uint8Array(width*height),queue=new Uint32Array(width*height);let head=0,tail=0;
 const visit=n=>{if(n<0||n>=visited.length||visited[n])return;visited[n]=1;const i=n*4;if(data[i]>242&&data[i+1]>242&&data[i+2]>242){data[i+3]=0;queue[tail++]=n;}};
 for(let x=0;x<width;x++){visit(x);visit((height-1)*width+x);}for(let y=0;y<height;y++){visit(y*width);visit(y*width+width-1);}
 while(head<tail){const n=queue[head++],x=n%width;if(x)visit(n-1);if(x<width-1)visit(n+1);visit(n-width);visit(n+width);}return data;
}
export async function stickerTexture(handle,cutout=true,signal,crop=true){
 const response=await fetch(`/api/ar/image/${encodeURIComponent(handle)}`,{signal});if(!response.ok)throw new Error('The sticker photo could not load. Try again.');
 const blob=await response.blob(),url=URL.createObjectURL(blob),img=new Image();
 try{img.src=url;await img.decode();if(signal?.aborted)throw new Error('Preparation cancelled.');
 const scale=Math.min(1,768/Math.max(img.naturalWidth,img.naturalHeight)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0,canvas.width,canvas.height);
 if(!cutout)return canvas;
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);removeEdgeWhite(pixels.data,canvas.width,canvas.height);ctx.putImageData(pixels,0,0);if(!crop)return canvas;
 let left=canvas.width,top=canvas.height,right=-1,bottom=-1;for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++){if(pixels.data[(y*canvas.width+x)*4+3]>16){left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);}}
 if(right<left)throw new Error('No artwork remained after removing white. Turn background removal off and try again.');
 const result=document.createElement('canvas');result.width=right-left+1;result.height=bottom-top+1;result.getContext('2d').drawImage(canvas,left,top,result.width,result.height,0,0,result.width,result.height);return result;
 }finally{URL.revokeObjectURL(url);}
}
